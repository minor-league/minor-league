package com.example.four_idiots

import io.ktor.client.*
import io.ktor.client.engine.cio.*

class HttpRequestHelper {
    private val client: HttpClient = HttpClient(CIO)
}