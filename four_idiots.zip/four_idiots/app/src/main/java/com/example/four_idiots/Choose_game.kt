package com.example.four_idiots

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.four_idiots.databinding.ActivityChooseGameBinding


class Choose_game : AppCompatActivity() {
    private lateinit var binding: ActivityChooseGameBinding
    lateinit var dbHelper: DBHelper_two
    lateinit var database: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChooseGameBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        dbHelper = DBHelper_two(this, "mydb.db", null, 1)
        database = dbHelper.writableDatabase

        binding.submit.setOnClickListener {
            var query = "INSERT INTO animals('animal') values('${binding.gameOne.text}');"
            database.execSQL(query)
            Toast.makeText(this, "저장 되었습니다.${binding.gameOne.text}", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, recommend::class.java)
            startActivity(intent)
        }


    }

}
