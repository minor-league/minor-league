package com.example.four_idiots

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import com.example.four_idiots.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    lateinit var dbHelper: DBHelper
    lateinit var database: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        dbHelper = DBHelper(this, "mydb.db", null, 1)
        database = dbHelper.writableDatabase

        binding.insert.setOnClickListener {
            var query = "INSERT INTO animals('animal') values('${binding.edit.text}');"
            database.execSQL(query)
            Toast.makeText(this, "회원가입 되었습니다.${binding.edit.text}", Toast.LENGTH_SHORT).show()
        }
        binding.select.setOnClickListener {
            var animals = mutableListOf<String>()
            var query = "SELECT * FROM animals;"
            var cursor = database.rawQuery(query, null)
            while(cursor.moveToNext()){
                var id = cursor.getString(cursor.getColumnIndex("id"))
                var animal = cursor.getString(cursor.getColumnIndex("animal"))
                animals.add("${id}/${animal}")
            }

            //var id = cursor.getString(cursor.getColumnIndex("id"))
            //Toast.makeText(this, animals.toString(), Toast.LENGTH_SHORT).show()
            if(animals==cursor){
                //비밀번호가 틀렸습니다.
                Toast.makeText(this, "로그인 실패${binding.edit.text}", Toast.LENGTH_SHORT).show()
            }else {
                Toast.makeText(this, "로그인 성공${binding.edit.text}", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, Choose_game::class.java)
                startActivity(intent)
            }



        }

    }
}