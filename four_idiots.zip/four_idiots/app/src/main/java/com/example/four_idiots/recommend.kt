package com.example.four_idiots

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_recommend.*

class recommend : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            //setContentView(R.layout.activity_recommend)
            setContentView(R.layout.activity_recommend)
            //http 통신 통해서 받아온 게임 정보 기재
            view_details.setOnClickListener{
                val intent = Intent(this, review::class.java)
                startActivity(intent)
            }

    }

}