package com.example.four_idiots

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.four_idiots.databinding.ActivityReviewBinding

class review : AppCompatActivity(){

    private lateinit var binding: ActivityReviewBinding
    lateinit var dbHelper: DBHelper_review_and_rating
    lateinit var database: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityReviewBinding.inflate(layoutInflater)
            val view = binding.root
            setContentView(view)
            dbHelper = DBHelper_review_and_rating(this, "mydb.db", null, 1)
            database = dbHelper.writableDatabase
            //setContentView(R.layout.activity_recommend)

            binding.submitReview.setOnClickListener{
                var query = "INSERT INTO animals('animal') values('${binding.typeReview.text}');"
                database.execSQL(query)
                Toast.makeText(this, "저장 되었습니다.${binding.typeReview.text}", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, LAST::class.java)
                startActivity(intent)
            }

    }

}